HEYYYY 
This a amazone clone app which i created using html and css
